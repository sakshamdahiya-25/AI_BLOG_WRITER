openai_api_key=""
google_gemini_api_key="AIzaSyCW99pEJ1So5Bc-RXa_9l5oPP2T1Umi-bo"