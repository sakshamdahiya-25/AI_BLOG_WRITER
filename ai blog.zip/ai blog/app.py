import os
import streamlit as st
import google.generativeai as genai
from apikey import google_gemini_api_key
genai.configure(api_key=google_gemini_api_key)

generation_config = {
  "temperature": 1,
  "top_p": 0.95,
  "top_k": 40,
  "max_output_tokens": 8192,
  "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
  model_name="gemini-2.0-flash",
  generation_config=generation_config,
)




st.set_page_config(layout="wide")
st.title("AI Blog : Write your Blogs!")

with st.sidebar: 
    st.title("Input Your Blog Details") 
    st.subheader("Enter Details of the Blog You want to generate") 
    
    #Blog title 
    blog_title=st.text_input("Blog Title") 
    # Keywords input 
    keywords = st.text_area("Keywords (comma-separated)") 
    # Number of words 
    num_words = st.slider("Number of Words", min_value=250, max_value=1000, step=250) 

    #Number of images 
    num_images = st.number_input("Number of Images", min_value=1, max_value=5, step=1)
    
    prompt_parts = [
        f"Generate a comprehensive , engaging blog post relevant to the given title \"{blog_title}\" and keywords \"{keywords}\". Make sure to incorporate these keywords in the blog post. The blog should be approximately {num_words} words in length , suitable for an online audience. Ensure the content is original , informative and maintains a consistent tone throughout. ",

    ]
    response = model.generate_content(prompt_parts)
    submit_button = st.button("Create Blog!")
if submit_button:
    st.write(response.text)
